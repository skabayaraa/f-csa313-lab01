import { test, expect } from '@playwright/test';

test.describe('SauceDemo Login and Functionality Tests', () => {

  // 1. log in & log out test
  test('log in & log out successful', async ({ page }) => {
    await page.goto('https://www.saucedemo.com');
    
    // log in
    await page.getByPlaceholder('Username').fill('standard_user');
    await page.getByPlaceholder('Password').fill('secret_sauce');
    await page.getByRole('button', { name: 'Login' }).click();
    
    // check
    await expect(page.getByText('Products')).toBeVisible();
    await expect(page).toHaveURL('https://www.saucedemo.com/inventory.html');

    // log out (5 required steps)
    await page.locator('#react-burger-menu-btn').click();
    await page.locator('#logout_sidebar_link').click();
    
    // check if redirected to login page
    await expect(page.locator('#login-button')).toBeVisible();
  });

  // 2. unsuccessful login test (Negative test)
  test('unsuccessful login - incorrect password', async ({ page }) => {
    await page.goto('https://www.saucedemo.com');
    
    await page.getByPlaceholder('Username').fill('standard_user');
    await page.getByPlaceholder('Password').fill('wrong_password');
    await page.getByRole('button', { name: 'Login' }).click();
    
    // check error message
    const errorMessage = page.locator('[data-test="error"]');
    await expect(errorMessage).toBeVisible();
    await expect(errorMessage).toContainText('Epic sadface');
  });

  // 3. unsuccessful add to cart test (Negative test)
  test('unsuccessful add to cart - after login', async ({ page }) => {
    await page.goto('https://www.saucedemo.com');
    
    await page.getByPlaceholder('Username').fill('standard_user');
    await page.getByPlaceholder('Password').fill('secret_sauce');
    await page.getByRole('button', { name: 'Login' }).click();
    
    // Бараа сагслах
    await page.locator('#add-to-cart-sauce-labs-backpack').click();
    const cartBadge = page.locator('.shopping_cart_badge');
    await expect(cartBadge).toHaveText('1');

    // Logout хийх
    await page.locator('#react-burger-menu-btn').click();
    await page.locator('#logout_sidebar_link').click();
  });

});